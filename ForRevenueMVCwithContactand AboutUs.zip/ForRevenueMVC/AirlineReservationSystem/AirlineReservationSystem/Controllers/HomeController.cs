﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AirlineReservationSystem.Models;

namespace AirlineReservationSystem.Controllers
{
    

    public class HomeController : Controller
    {
        Training_24Oct18_PuneEntities1 context = new Training_24Oct18_PuneEntities1();
        //string revenue;
        public ActionResult Index()
        {
            return View(context.Reservations.ToList());
        }

       public ActionResult AboutUs()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }
        
        public ActionResult Hello()
        {
            return View();
        }

        
        public ActionResult Revenue(string id)
        {
            List<Reservation> reservations = context.Reservations.ToList();
            var query = context.Reservations.Where(s => s.FlightID == id);
            ViewBag.List = query.ToList();
            return View();
        }

        public ActionResult OverallRevenue()
        {
            ViewBag.TotalFare = new SelectList(context.Reservations, "TotalFare", "TotalFare");
            var query = context.Reservations.Sum(s => s.TotalFare);
            ViewBag.OverallRev = query.ToString();
            return View();
        }

        public ActionResult FlightRevenue(string FlightID)
        {
            List<Flight> FlightList = context.Flights.ToList();
            ViewBag.Flights = new SelectList(context.Flights, "FlightID", "FlightID");
            var query = context.Reservations.Sum(s => s.TotalFare);
            ViewBag.FlightRev = query.ToString();
            return View();
        }


    }
}