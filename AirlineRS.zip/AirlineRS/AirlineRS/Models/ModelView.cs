﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AirlineRS.Models
{
    public class ModelView
    {
        public Flight flight { get; set; }
        public FlightClass flightClass { get; set; }
        public Reservation reservation { get; set; }
        public User user { get; set; }
        public USP_VIEWFLIGHTS_Result viewFlight { get; set; }
        public USP_VIEWRESERVATION_Result viewReservation { get; set; }
    }
}