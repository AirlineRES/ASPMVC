﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AirlineRS.Models;

namespace AirlineRS.Controllers
{
    public class AdminController : Controller
    {
        private TrainingEntities db = new TrainingEntities();

        // GET: Flights
        public async Task<ActionResult> Index()
        {
            return View(await db.Flights.ToListAsync());
        }

       

        // GET: Flights/AddFlight
        public ActionResult AddFlight()
        {

            ViewBag.Hide = true;

            return View();
        }

        // POST: Flights/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public async Task<ActionResult> AddFlight([Bind(Include = "FlightID,LaunchDate,Origin,Destination,DeptTime,ArrivalTime,NoOfSeats,Class,Fare,TotalSeats")] ModelView modelView)
        {
            if (ModelState.IsValid)
            {
                Flight flight = new Flight();
                FlightClass flightClass = new FlightClass();
                db.Flights.Add(flight);
                db.FlightClasses.Add(flightClass);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(modelView);
        }

        public ActionResult RemoveFlight(string id)
        {
            Flight flight = db.Flights.Find(id);
            if (flight == null)
            {
                return HttpNotFound();
            }
            return View(flight);
        }

        [HttpPost]
        public ActionResult RemovedFlight(string id)
        {
            Flight flight = db.Flights.Find(id);
            db.Flights.Remove(flight);
            db.SaveChangesAsync();
            return RedirectToAction("Index");
        }


        // GET: Flights/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Flight flight = await db.Flights.FindAsync(id);
            if (flight == null)
            {
                return HttpNotFound();
            }
            return View(flight);
        }

        // POST: Flights/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            Flight flight = await db.Flights.FindAsync(id);
            db.Flights.Remove(flight);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
