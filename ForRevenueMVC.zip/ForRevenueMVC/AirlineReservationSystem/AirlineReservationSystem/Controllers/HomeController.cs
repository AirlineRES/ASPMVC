﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AirlineReservationSystem.Models;

namespace AirlineReservationSystem.Controllers
{
    

    public class HomeController : Controller
    {
        Training_24Oct18_PuneEntities1 context = new Training_24Oct18_PuneEntities1();
        //string revenue;
        public ActionResult Index()
        {
            return View(context.Reservations.ToList());
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        
        public ActionResult Revenue(string id)
        {
            List<Reservation> reservations = context.Reservations.ToList();
            var query = context.Reservations.Where(s => s.FlightID == id);
            ViewBag.List = query.ToList();
            return View();
        }


    }
}